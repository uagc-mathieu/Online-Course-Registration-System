<?php
require_once __DIR__ . '/config.php';

/**
 * Database
 *
 * Custom connection class that centralizes access to MySQL through
 * PDO. Every page that needs the database (register.php, login.php)
 * asks Database::getConnection() instead of opening its own
 * connection, so credentials and error handling live in one place.
 *
 * A static/singleton pattern is used here so repeated calls within
 * the same request reuse the same PDO instance rather than opening
 * a new socket to MySQL every time.
 */
class Database
{
    private static ?PDO $connection = null;

    public static function getConnection(): PDO
    {
        if (self::$connection === null) {
            $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';

            $options = [
                // Turn MySQL errors into exceptions instead of silent
                // failures, so register.php/login.php can catch them.
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                // Return rows as associative arrays ($row['email']).
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                // Use real prepared statements (not emulated) so bound
                // values are never interpolated into the SQL string.
                PDO::ATTR_EMULATE_PREPARES   => false,
            ];

            try {
                self::$connection = new PDO($dsn, DB_USER, DB_PASS, $options);
            } catch (PDOException $e) {
                // Never surface raw DB error text to the browser.
                error_log('Database connection failed: ' . $e->getMessage());
                die('Unable to connect to the database. Please try again later.');
            }
        }

        return self::$connection;
    }
}
