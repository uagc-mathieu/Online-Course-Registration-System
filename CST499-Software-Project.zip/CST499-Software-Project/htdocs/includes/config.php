<?php
// Database connection settings for XAMPP/MySQL.
// Update DB_USER / DB_PASS if your local MySQL root account uses a
// password. Update DB_PORT if MySQL isn't running on the standard
// 3306 port -- check xampp/phpMyAdmin/config.inc.php for the port
// and credentials phpMyAdmin is already using successfully.

define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3307');
define('DB_NAME', 'course_registration');
define('DB_USER', 'root');
define('DB_PASS', '');
