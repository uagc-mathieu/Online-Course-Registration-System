<?php
// Include this at the top of any page that requires an active login
// (before includes/header.php). Redirects anonymous visitors to the
// login page rather than letting them view/modify enrollment data.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['id'])) {
    header('Location: login.php');
    exit;
}
