</main>
<footer class="bg-light text-center text-muted py-3 mt-5 border-top">
    <div class="container">
        &copy; <?= date('Y') ?> Course Registration System
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
