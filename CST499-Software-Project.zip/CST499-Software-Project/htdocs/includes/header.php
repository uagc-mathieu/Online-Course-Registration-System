<?php if (session_status() === PHP_SESSION_NONE) { session_start(); } ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? htmlspecialchars($pageTitle) . ' | ' : '' ?>Course Registration System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="landing.php">Course Registration System</a>
        <div class="navbar-nav ms-auto">
            <?php if (!empty($_SESSION['user_id'])): ?>
                <a class="nav-link" href="courses.php">Courses</a>
                <a class="nav-link" href="schedule.php">My Schedule</a>
                <span class="nav-link text-light">Signed in as <?= htmlspecialchars($_SESSION['user_id']) ?></span>
                <a class="nav-link" href="logout.php">Log Out</a>
            <?php else: ?>
                <a class="nav-link" href="login.php">Log In</a>
                <a class="nav-link" href="register.php">Register</a>
            <?php endif; ?>
        </div>
    </div>
</nav>
<main class="container py-5">
