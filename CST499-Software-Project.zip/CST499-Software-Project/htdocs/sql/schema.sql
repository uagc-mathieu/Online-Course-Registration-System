-- ============================================================
-- Online Course Registration System
-- Database + Users table
-- Run this in phpMyAdmin (or the mysql CLI) before loading any
-- of the PHP pages. Creates the schema that register.php and
-- login.php read from/write to.
-- ============================================================

CREATE DATABASE IF NOT EXISTS course_registration
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE course_registration;

-- Stores the account data captured on the registration page
-- (REQ-1) and checked at login (REQ-3). user_id is the unique
-- login ID the student picks; the UNIQUE constraint is what lets
-- REQ-2 be enforced at the database level as well as in PHP.
CREATE TABLE IF NOT EXISTS users (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id       VARCHAR(30)  NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name     VARCHAR(100) NOT NULL,
    phone_number  VARCHAR(20)  NOT NULL,
    email         VARCHAR(150) NOT NULL UNIQUE,
    created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Course catalog (REQ-4: list courses offered for a selected term).
-- seat_limit is set independently per course (REQ-5's enrollment cap).
CREATE TABLE IF NOT EXISTS courses (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    course_code VARCHAR(10)  NOT NULL,
    title       VARCHAR(150) NOT NULL,
    term        ENUM('Spring', 'Summer', 'Fall') NOT NULL,
    seat_limit  INT UNSIGNED NOT NULL,
    created_at  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_course_term (course_code, term)
) ENGINE=InnoDB;

-- Links a student to a course with a status of either 'enrolled'
-- (REQ-5) or 'waitlisted' (REQ-6). Dropping a course (REQ-7) deletes
-- the row here; when the dropped row was 'enrolled', the earliest
-- 'waitlisted' row for that course is promoted (REQ-8). The UNIQUE
-- constraint keeps a student from registering for the same course twice.
CREATE TABLE IF NOT EXISTS enrollments (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id    INT UNSIGNED NOT NULL,
    course_id  INT UNSIGNED NOT NULL,
    status     ENUM('enrolled', 'waitlisted') NOT NULL,
    created_at TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_user_course (user_id, course_id),
    CONSTRAINT fk_enroll_user   FOREIGN KEY (user_id)   REFERENCES users(id)   ON DELETE CASCADE,
    CONSTRAINT fk_enroll_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
) ENGINE=InnoDB;
