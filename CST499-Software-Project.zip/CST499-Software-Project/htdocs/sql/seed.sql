-- Sample course catalog for demoing/testing REQ-4 through REQ-8.
-- Optional: run after schema.sql if you want data to register for.
-- Seat limits are set low on purpose so it's easy to fill a course
-- and see the waitlist (REQ-6) and promotion-on-drop (REQ-8) logic.

USE course_registration;

INSERT INTO courses (course_code, title, term, seat_limit) VALUES
    ('CST499', 'Capstone', 'Fall', 2),
    ('CST310', 'Applied Software Development', 'Fall', 3),
    ('CST231', 'Database Design', 'Fall', 2),
    ('CST300', 'Web Systems and Technologies', 'Spring', 3),
    ('CST321', 'Client-Side Development', 'Spring', 2),
    ('CST311', 'Computer Networks', 'Summer', 3);
