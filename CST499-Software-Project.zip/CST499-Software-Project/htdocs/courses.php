<?php
require_once __DIR__ . '/includes/Database.php';
require_once __DIR__ . '/includes/auth.php';

$pageTitle = 'Courses';
$pdo = Database::getConnection();

$terms = ['Spring', 'Summer', 'Fall'];
$selectedTerm = in_array($_GET['term'] ?? '', $terms, true) ? $_GET['term'] : 'Fall';

// ---- Handle an enrollment request (REQ-5 / REQ-6) --------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['course_id'])) {
    $courseId = (int) $_POST['course_id'];
    $userId   = (int) $_SESSION['id'];

    // Guard against a student registering for the same course twice.
    $already = $pdo->prepare('SELECT id FROM enrollments WHERE user_id = :uid AND course_id = :cid');
    $already->execute(['uid' => $userId, 'cid' => $courseId]);

    if ($already->fetch()) {
        $_SESSION['flash'] = ['type' => 'warning', 'text' => 'You are already registered for that course.'];
    } else {
        // REQ-4/5: how many seats are already taken vs. the course's
        // independently-set seat_limit.
        $course = $pdo->prepare('SELECT seat_limit, course_code FROM courses WHERE id = :id');
        $course->execute(['id' => $courseId]);
        $course = $course->fetch();

        $taken = $pdo->prepare("SELECT COUNT(*) AS n FROM enrollments WHERE course_id = :cid AND status = 'enrolled'");
        $taken->execute(['cid' => $courseId]);
        $seatsTaken = (int) $taken->fetch()['n'];

        // REQ-5: enroll directly if a seat is open.
        // REQ-6: otherwise place the student on the waitlist instead.
        $status = ($seatsTaken < (int) $course['seat_limit']) ? 'enrolled' : 'waitlisted';

        $insert = $pdo->prepare(
            'INSERT INTO enrollments (user_id, course_id, status) VALUES (:uid, :cid, :status)'
        );
        $insert->execute(['uid' => $userId, 'cid' => $courseId, 'status' => $status]);

        $_SESSION['flash'] = $status === 'enrolled'
            ? ['type' => 'success', 'text' => "You're enrolled in {$course['course_code']}."]
            : ['type' => 'info', 'text' => "{$course['course_code']} is full \u2014 you've been added to the waitlist."];
    }

    header('Location: courses.php?term=' . urlencode($selectedTerm));
    exit;
}

// ---- REQ-4: list the courses offered for the selected term, with
//      each student's own registration status if any -------------------
$stmt = $pdo->prepare(
    "SELECT c.id, c.course_code, c.title, c.seat_limit,
            (SELECT COUNT(*) FROM enrollments e WHERE e.course_id = c.id AND e.status = 'enrolled') AS seats_taken,
            (SELECT status FROM enrollments e WHERE e.course_id = c.id AND e.user_id = :uid) AS my_status
     FROM courses c
     WHERE c.term = :term
     ORDER BY c.course_code"
);
$stmt->execute(['uid' => $_SESSION['id'], 'term' => $selectedTerm]);
$courses = $stmt->fetchAll();

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

require_once __DIR__ . '/includes/header.php';
?>

<h1 class="mb-4">Course Registration</h1>

<?php if ($flash): ?>
    <div class="alert alert-<?= htmlspecialchars($flash['type']) ?>"><?= htmlspecialchars($flash['text']) ?></div>
<?php endif; ?>

<ul class="nav nav-tabs mb-4">
    <?php foreach ($terms as $term): ?>
        <li class="nav-item">
            <a class="nav-link <?= $term === $selectedTerm ? 'active' : '' ?>"
               href="courses.php?term=<?= urlencode($term) ?>"><?= htmlspecialchars($term) ?></a>
        </li>
    <?php endforeach; ?>
</ul>

<?php if (empty($courses)): ?>
    <p class="text-muted">No courses are offered for <?= htmlspecialchars($selectedTerm) ?> yet.</p>
<?php else: ?>
    <table class="table table-bordered align-middle bg-white">
        <thead class="table-light">
            <tr>
                <th>Code</th>
                <th>Title</th>
                <th>Seats</th>
                <th>Status</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($courses as $course): ?>
            <?php $seatsLeft = max(0, $course['seat_limit'] - $course['seats_taken']); ?>
            <tr>
                <td><?= htmlspecialchars($course['course_code']) ?></td>
                <td><?= htmlspecialchars($course['title']) ?></td>
                <td><?= $seatsLeft ?> of <?= (int) $course['seat_limit'] ?> open</td>
                <td>
                    <?php if ($course['my_status'] === 'enrolled'): ?>
                        <span class="badge text-bg-success">Enrolled</span>
                    <?php elseif ($course['my_status'] === 'waitlisted'): ?>
                        <span class="badge text-bg-warning">Waitlisted</span>
                    <?php else: ?>
                        <span class="text-muted">&mdash;</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if (!$course['my_status']): ?>
                        <form method="post" action="courses.php?term=<?= urlencode($selectedTerm) ?>">
                            <input type="hidden" name="course_id" value="<?= (int) $course['id'] ?>">
                            <button type="submit" class="btn btn-sm btn-primary">
                                <?= $seatsLeft > 0 ? 'Register' : 'Join Waitlist' ?>
                            </button>
                        </form>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
