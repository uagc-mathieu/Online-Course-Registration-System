<?php
require_once __DIR__ . '/includes/Database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$pageTitle = 'Log In';
$errors = [];
$userIdInput = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userIdInput = trim($_POST['user_id'] ?? '');
    $password    = $_POST['password'] ?? '';

    if ($userIdInput === '' || $password === '') {
        $errors[] = 'Please enter both a User ID and password.';
    } else {
        $pdo = Database::getConnection();

        $stmt = $pdo->prepare('SELECT id, user_id, password_hash, full_name FROM users WHERE user_id = :user_id');
        $stmt->execute(['user_id' => $userIdInput]);
        $user = $stmt->fetch();

        // REQ-3: verify credentials; deny login with an error
        // message when the ID/password do not match a stored
        // account. The same generic message is used whether the
        // ID doesn't exist or the password is wrong, so a login
        // attempt can't be used to discover which IDs are registered.
        if ($user && password_verify($password, $user['password_hash'])) {
            $_SESSION['id']         = $user['id'];
            $_SESSION['user_id']    = $user['user_id'];
            $_SESSION['full_name']  = $user['full_name'];
            header('Location: schedule.php');
            exit;
        } else {
            $errors[] = 'Incorrect User ID or password.';
        }
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-5">
        <h1 class="mb-4">Log In</h1>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errors as $error): ?>
                        <li><?= htmlspecialchars($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="post" action="login.php" novalidate>
            <div class="mb-3">
                <label for="user_id" class="form-label">User ID</label>
                <input type="text" class="form-control" id="user_id" name="user_id"
                       value="<?= htmlspecialchars($userIdInput) ?>" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Log In</button>
        </form>

        <p class="text-center mt-3">
            Don't have an account? <a href="register.php">Register</a>.
        </p>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
