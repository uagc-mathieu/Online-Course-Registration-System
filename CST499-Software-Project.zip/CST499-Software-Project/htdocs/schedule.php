<?php
require_once __DIR__ . '/includes/Database.php';
require_once __DIR__ . '/includes/auth.php';

$pageTitle = 'My Schedule';
$pdo = Database::getConnection();
$userId = (int) $_SESSION['id'];

// ---- Handle a drop request (REQ-7), with waitlist promotion (REQ-8) --
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['course_id'])) {
    $courseId = (int) $_POST['course_id'];

    // Find the enrollment being dropped so we know whether it held a
    // seat (only a dropped 'enrolled' row frees a seat to promote into).
    $find = $pdo->prepare('SELECT status FROM enrollments WHERE user_id = :uid AND course_id = :cid');
    $find->execute(['uid' => $userId, 'cid' => $courseId]);
    $dropped = $find->fetch();

    if ($dropped) {
        $pdo->beginTransaction();

        $delete = $pdo->prepare('DELETE FROM enrollments WHERE user_id = :uid AND course_id = :cid');
        $delete->execute(['uid' => $userId, 'cid' => $courseId]);

        // REQ-8: when the dropped seat was an active enrollment, promote
        // the earliest-registered waitlisted student into it. (The SRS
        // leaves the student's confirmation window for this open as a
        // documented TBD item -- this implementation promotes directly
        // rather than holding the seat pending a confirmation step.)
        if ($dropped['status'] === 'enrolled') {
            $next = $pdo->prepare(
                "SELECT id FROM enrollments
                 WHERE course_id = :cid AND status = 'waitlisted'
                 ORDER BY created_at ASC
                 LIMIT 1"
            );
            $next->execute(['cid' => $courseId]);
            $next = $next->fetch();

            if ($next) {
                $promote = $pdo->prepare("UPDATE enrollments SET status = 'enrolled' WHERE id = :id");
                $promote->execute(['id' => $next['id']]);
            }
        }

        $pdo->commit();
        $_SESSION['flash'] = ['type' => 'success', 'text' => 'Course dropped from your schedule.'];
    }

    header('Location: schedule.php');
    exit;
}

// ---- List this student's current enrollments -------------------------
$stmt = $pdo->prepare(
    "SELECT c.id, c.course_code, c.title, c.term, e.status
     FROM enrollments e
     JOIN courses c ON c.id = e.course_id
     WHERE e.user_id = :uid
     ORDER BY c.term, c.course_code"
);
$stmt->execute(['uid' => $userId]);
$schedule = $stmt->fetchAll();

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

require_once __DIR__ . '/includes/header.php';
?>

<h1 class="mb-4">My Schedule</h1>

<?php if ($flash): ?>
    <div class="alert alert-<?= htmlspecialchars($flash['type']) ?>"><?= htmlspecialchars($flash['text']) ?></div>
<?php endif; ?>

<?php if (empty($schedule)): ?>
    <p class="text-muted">
        You aren't registered for any courses yet.
        <a href="courses.php">Browse courses</a> to get started.
    </p>
<?php else: ?>
    <table class="table table-bordered align-middle bg-white">
        <thead class="table-light">
            <tr>
                <th>Term</th>
                <th>Code</th>
                <th>Title</th>
                <th>Status</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($schedule as $row): ?>
            <tr>
                <td><?= htmlspecialchars($row['term']) ?></td>
                <td><?= htmlspecialchars($row['course_code']) ?></td>
                <td><?= htmlspecialchars($row['title']) ?></td>
                <td>
                    <?php if ($row['status'] === 'enrolled'): ?>
                        <span class="badge text-bg-success">Enrolled</span>
                    <?php else: ?>
                        <span class="badge text-bg-warning">Waitlisted</span>
                    <?php endif; ?>
                </td>
                <td>
                    <form method="post" action="schedule.php" onsubmit="return confirm('Drop this course?');">
                        <input type="hidden" name="course_id" value="<?= (int) $row['id'] ?>">
                        <button type="submit" class="btn btn-sm btn-outline-danger">Drop</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<p><a href="courses.php" class="btn btn-primary">Add More Courses</a></p>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
