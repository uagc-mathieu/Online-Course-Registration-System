<?php
$pageTitle = 'Welcome';
require_once __DIR__ . '/includes/header.php';
?>

<div class="p-5 mb-4 bg-body-tertiary rounded-3 text-center">
    <h1 class="display-5 fw-bold">Course Registration System</h1>
    <p class="col-lg-8 mx-auto fs-5">
        Create an account, log in, and enroll in courses for the upcoming semester.
        New here? Register for an account to get started. Already have an account?
        Log in below.
    </p>
    <div class="d-flex justify-content-center gap-2">
        <a href="register.php" class="btn btn-primary btn-lg">Register</a>
        <a href="login.php" class="btn btn-outline-secondary btn-lg">Log In</a>
    </div>
</div>

<div class="row g-4">
    <div class="col-md-4">
        <h3>1. Register</h3>
        <p>Create an account with a unique user ID, your name, phone number, and email.</p>
    </div>
    <div class="col-md-4">
        <h3>2. Log In</h3>
        <p>Sign in with the ID and password you created during registration.</p>
    </div>
    <div class="col-md-4">
        <h3>3. Enroll</h3>
        <p>Browse course offerings for the semester and enroll in open sections.</p>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
