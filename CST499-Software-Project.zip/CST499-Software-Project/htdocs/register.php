<?php
require_once __DIR__ . '/includes/Database.php';

$pageTitle = 'Register';
$errors = [];
$success = false;

// Keep submitted values so the form can be redisplayed with the
// user's input intact if validation fails (except passwords).
$formData = [
    'user_id'      => '',
    'full_name'    => '',
    'phone_number' => '',
    'email'        => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // ---- 1. Collect and sanitize input -----------------------
    $formData['user_id']      = trim($_POST['user_id'] ?? '');
    $formData['full_name']    = trim($_POST['full_name'] ?? '');
    $formData['phone_number'] = trim($_POST['phone_number'] ?? '');
    $formData['email']        = trim($_POST['email'] ?? '');
    $password        = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    // ---- 2. Validate (REQ-1: ID, password, name, phone, email) --
    if ($formData['user_id'] === '' || !preg_match('/^[A-Za-z0-9_]{4,30}$/', $formData['user_id'])) {
        $errors[] = 'User ID must be 4-30 characters (letters, numbers, underscore only).';
    }
    if ($formData['full_name'] === '') {
        $errors[] = 'Full name is required.';
    }
    if ($formData['phone_number'] === '' || !preg_match('/^[0-9()\-\s+]{7,20}$/', $formData['phone_number'])) {
        $errors[] = 'A valid phone number is required.';
    }
    if (!filter_var($formData['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'A valid email address is required.';
    }
    if (strlen($password) < 8) {
        $errors[] = 'Password must be at least 8 characters.';
    }
    if ($password !== $confirmPassword) {
        $errors[] = 'Password and confirmation do not match.';
    }

    // ---- 3. Only touch the database once input passes basic
    //         validation ----------------------------------------
    if (empty($errors)) {
        $pdo = Database::getConnection();

        // REQ-2: reject registration if the ID is already taken.
        $check = $pdo->prepare('SELECT id FROM users WHERE user_id = :user_id');
        $check->execute(['user_id' => $formData['user_id']]);

        if ($check->fetch()) {
            $errors[] = 'That User ID is already taken. Please choose a different one.';
        } else {
            // password_hash() uses bcrypt by default, so the plain
            // password is never written to the database.
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);

            $insert = $pdo->prepare(
                'INSERT INTO users (user_id, password_hash, full_name, phone_number, email)
                 VALUES (:user_id, :password_hash, :full_name, :phone_number, :email)'
            );

            try {
                $insert->execute([
                    'user_id'       => $formData['user_id'],
                    'password_hash' => $passwordHash,
                    'full_name'     => $formData['full_name'],
                    'phone_number'  => $formData['phone_number'],
                    'email'         => $formData['email'],
                ]);
                $success = true;
                $formData = ['user_id' => '', 'full_name' => '', 'phone_number' => '', 'email' => ''];
            } catch (PDOException $e) {
                // Catches the race condition where a duplicate email
                // slips past the check above (UNIQUE constraint on
                // email in the users table) and any other DB error.
                error_log('Registration insert failed: ' . $e->getMessage());
                $errors[] = 'That email address is already registered, or registration failed. Please try again.';
            }
        }
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <h1 class="mb-4">Create an Account</h1>

        <?php if ($success): ?>
            <div class="alert alert-success">
                Account created successfully. You can now
                <a href="login.php" class="alert-link">log in</a>.
            </div>
        <?php endif; ?>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errors as $error): ?>
                        <li><?= htmlspecialchars($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="post" action="register.php" novalidate>
            <div class="mb-3">
                <label for="user_id" class="form-label">User ID</label>
                <input type="text" class="form-control" id="user_id" name="user_id"
                       value="<?= htmlspecialchars($formData['user_id']) ?>" required>
            </div>
            <div class="mb-3">
                <label for="full_name" class="form-label">Full Name</label>
                <input type="text" class="form-control" id="full_name" name="full_name"
                       value="<?= htmlspecialchars($formData['full_name']) ?>" required>
            </div>
            <div class="mb-3">
                <label for="phone_number" class="form-label">Phone Number</label>
                <input type="tel" class="form-control" id="phone_number" name="phone_number"
                       value="<?= htmlspecialchars($formData['phone_number']) ?>" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email Address</label>
                <input type="email" class="form-control" id="email" name="email"
                       value="<?= htmlspecialchars($formData['email']) ?>" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <div class="mb-3">
                <label for="confirm_password" class="form-label">Confirm Password</label>
                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Register</button>
        </form>

        <p class="text-center mt-3">
            Already have an account? <a href="login.php">Log in</a>.
        </p>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
